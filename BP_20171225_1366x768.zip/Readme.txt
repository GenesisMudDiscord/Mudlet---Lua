Basic Package 20171225
Set of mudlet tools for genesis mud
[[--
The package BP was put together from:
--
Magic Map:
Map20170610.zip by Findis
https://www.genesismud.org/forums/viewtopic.php?f=14&t=4004&start=20#p37298
--
Chat Box using GMPC:
Chat20170610.zip by Findis 
https://www.genesismud.org/forums/viewtopic.php?f=14&t=4004&start=20#p37298
--
WList - Wielded/Worn Items List:
based on For_Genesis_20130329b1.xml package by Hairetikos
https://www.genesismud.org/forums/viewtopic.php?f=14&t=2098&start=80#p18248
--
Vitals - Set of Vital Bars using GMPC
https://www.genesismud.org/forums/viewtopic.php?f=14&t=2098&start=110#p31142
--
Other:
Enchantments - translation of imbued ones descriptions
Queue - creates an alias that can be used to set a delay u want between commands
http://genesisquests.pbworks.com/w/page/118675659/Mudlet%20Package%20-%20Command%20Queue
Herb info
Targeting alias
Kill counter
Misc
--
--]]
